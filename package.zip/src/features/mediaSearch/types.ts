export type SearchTerm =
{
    searchTerm: string,
    offset: number
}
